﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEstoque01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] produtosSemanas = new int[2, 4];
            string auxiliar = "";
            string imprimir = "";
            int totalProdutos = 0;
            int totalEntradas = 0;

            for (int p = 0; p < 2; p++)
            {
                for (int s = 0 ; s < 4; s++)
                {
                    auxiliar = Interaction.InputBox("Insira a quantidade de produtos " + (p+1) + " vendidos na semana " + (s+1));

                    if (!int.TryParse(auxiliar, out produtosSemanas[p,s]))
                    {
                        MessageBox.Show("Valor inválido. Digite um número inteiro.");
                        s--;
                    }
                    else
                    {
                        imprimir = "Total entradas do produto " + (p+1) + " - Semana " + (s+1) + ": " + produtosSemanas[p, s];
                        totalProdutos += produtosSemanas[p, s];
                        lstDestino.Items.Add(imprimir);
                    }
                }
                totalEntradas += totalProdutos;
                imprimir = ">> Total entradas do produto " + (p + 1) + ":               " + totalProdutos;
                lstDestino.Items.Add(imprimir);
                lstDestino.Items.Add("------------------------------------------------------------------");
                totalProdutos = 0;
            }

            lstDestino.Items.Add(">> Total geral entradas:                           " + totalEntradas);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstDestino.Items.Clear();
        }
    }
}
