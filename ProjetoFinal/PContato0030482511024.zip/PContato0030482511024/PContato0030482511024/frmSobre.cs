﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Diagnostics;
using System.Windows.Forms;

namespace PContato0030482511024
{
    public partial class frmSobre : Form
    {
        private readonly Random _rand = new Random();
        private readonly List<Action> _actions = new List<Action>();
        private readonly Dictionary<string, object> _originalValues = new Dictionary<string, object>();
        private int _actionIndex = 0;

        public frmSobre()
        {
            InitializeComponent();
            InitializePropertyActions();
        }

        // Método que deve ser ligado ao Click do botão no Designer
        public void ChangeOneProperty_Click(object sender, EventArgs e)
        {
            if (_actions.Count == 0) return;
            // Executa apenas UMA ação por clique
            try
            {
                _actions[_actionIndex].Invoke();
            }
            catch
            {
                // Não propagar exceções em brincadeiras de UI
            }
            _actionIndex = (_actionIndex + 1) % _actions.Count;
        }

        private void InitializePropertyActions()
        {
            // Garantir que controles existem (são definidos no Designer)
            // As ações abaixo mudam somente UMA propriedade por vez.
            // Sempre salvamos o valor original na primeira modificação para cada propriedade.
            _actions.Clear();

            // 1) Muda a cor do texto de lblNomeProduto
            _actions.Add(() =>
            {
                if (lblNomeProduto == null) return;
                SaveOriginal(lblNomeProduto, "ForeColor", lblNomeProduto.ForeColor);
                lblNomeProduto.ForeColor = RandomColor();
            });

            // 2) Move label1 para uma posição aleatória (apenas Location)
            _actions.Add(() =>
            {
                if (label1 == null) return;
                SaveOriginal(label1, "Location", label1.Location);
                var maxX = Math.Max(0, this.ClientSize.Width - label1.Width);
                var maxY = Math.Max(0, this.ClientSize.Height - label1.Height);
                label1.Location = new Point(_rand.Next(0, Math.Max(1, maxX)), _rand.Next(0, Math.Max(1, maxY)));
            });

            // 3) Alterna Visibility de label2 (apenas Visible)
            _actions.Add(() =>
            {
                if (label2 == null) return;
                SaveOriginal(label2, "Visible", label2.Visible);
                label2.Visible = !label2.Visible;
            });

            // 4) Altera o SizeMode do pictureBox1 (apenas SizeMode)
            _actions.Add(() =>
            {
                if (pictureBox1 == null) return;
                SaveOriginal(pictureBox1, "SizeMode", pictureBox1.SizeMode);
                var modes = Enum.GetValues(typeof(PictureBoxSizeMode)).Cast<PictureBoxSizeMode>().ToArray();
                pictureBox1.SizeMode = modes[_rand.Next(modes.Length)];
            });

            // 5) Ajusta o tamanho (Height) de label3 (apenas Size.Height)
            _actions.Add(() =>
            {
                if (label3 == null) return;
                SaveOriginal(label3, "Size", label3.Size);
                int newH = Math.Max(16, Math.Min(200, label3.Height + _rand.Next(-20, 40)));
                label3.Size = new Size(label3.Width, newH);
            });

            // 6) Muda a fonte de label4 (apenas Font)
            _actions.Add(() =>
            {
                if (label4 == null) return;
                SaveOriginal(label4, "Font", label4.Font);
                try
                {
                    float newSize = Math.Max(6f, Math.Min(36f, label4.Font.Size + _rand.Next(-4, 6)));
                    FontStyle style = (FontStyle)(_rand.Next(0, 2) == 0 ? FontStyle.Bold : FontStyle.Italic);
                    label4.Font = new Font(label4.Font.FontFamily, newSize, style);
                }
                catch
                {
                    // ignorar erro de fonte
                }
            });

            // 7) Altera o texto de label5 (apenas Text)
            _actions.Add(() =>
            {
                if (label5 == null) return;
                SaveOriginal(label5, "Text", label5.Text);
                // adiciona um emoji ou texto curto ao final (visível)
                label5.Text = label5.Text + " ✨";
            });

            // 8) Altera cor de fundo de label6 (apenas BackColor)
            _actions.Add(() =>
            {
                if (label6 == null) return;
                SaveOriginal(label6, "BackColor", label6.BackColor);
                label6.BackColor = RandomColor(100, 255);
            });

            // 9) Troca o texto de label7 por versão invertida (apenas Text)
            _actions.Add(() =>
            {
                if (label7 == null) return;
                SaveOriginal(label7, "Text", label7.Text);
                label7.Text = new string(label7.Text.Reverse().ToArray());
            });
        }

        private void SaveOriginal(Control ctrl, string propertyName, object value)
        {
            if (ctrl == null) return;
            string key = $"{ctrl.Name}.{propertyName}";
            if (!_originalValues.ContainsKey(key))
            {
                _originalValues[key] = value;
            }
        }

        // Utilitário para gerar cor aleatória
        private Color RandomColor(int min = 0, int max = 255)
        {
            int r = _rand.Next(min, Math.Min(256, max + 1));
            int g = _rand.Next(min, Math.Min(256, max + 1));
            int b = _rand.Next(min, Math.Min(256, max + 1));
            return Color.FromArgb(r, g, b);
        }
    }
}