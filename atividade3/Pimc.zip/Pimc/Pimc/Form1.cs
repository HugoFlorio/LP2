using System.Data;
using System.Linq.Expressions;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double pesoAtual, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPesoAtual.Clear();
            txtAltura.Clear();
            txtIMC.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
                {
                pesoAtual = Double.Parse(txtPesoAtual.Text);
                altura = Double.Parse(txtAltura.Text);
                imc = pesoAtual / (altura * altura);
                imc = Math.Round(imc, 1);

                if (imc < 18.5)
                    txtIMC.Text = "Peso abaixo do adequado.";
                else if (imc > 24.9)
                    txtIMC.Text = "Peso acima do adequado.";
                else
                    txtIMC.Text = "Peso adequado.";
            }
            catch
                { MessageBox.Show("Dados Inv�lidos."); }
        }

    }
}
